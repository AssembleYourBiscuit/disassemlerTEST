/**
 * File:   Test3.java
 * Author: Nicolas Michael
 * Date:   May 13, 2015
 * 
 * This class is used to test the run time of paints of threads
 * in each pair, one will be performing computational operations
 * and the other will be performing disk read and write operations
 */ 
class Test3 extends Thread 
{
	private int numPairs = 4;
  
	/**
	 * creates and executes all threads and reports run time
	 */ 
	public void run() 
	{
		long start = System.currentTimeMillis();
		String[] strArray1 = SysLib.stringToArgs("TestThread3a");
		String[] strArray2 = SysLib.stringToArgs("TestThread3b");
		
		//create numPairs pairs of threads and execute
		for (int i = 0; i < numPairs; i++) 
		{	
			SysLib.exec(strArray1);
			SysLib.exec(strArray2);
		}
	
		//wait for each to complete
		for (int i = 0; i < numPairs * 2; i++) 
		{
			SysLib.join();
		}
		
		long end = System.currentTimeMillis();
		SysLib.cout("Run time: " + (end - start) + " milliseconds.\n");
		SysLib.exit();
	}
}
