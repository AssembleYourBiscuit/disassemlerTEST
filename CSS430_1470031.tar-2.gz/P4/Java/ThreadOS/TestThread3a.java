/**
 * File:	 TestThread3a.java
 * Author:   Nicolas Michael
 * Date:	 May 13, 2015
 * 
 * This class is called by Test3.java to perform random
 * computations to test run time and waiting capabilities
 * of newly added monitors to threados
 */ 
 
 import java.util.Random;
 
class TestThread3a extends Thread 
{ 
	public void run() 
	{
		SysLib.cout("Computation thread started\n");
		computations();
		SysLib.exit();
	}
  
	/**
	 * performs random computations
	 */ 
	private void computations() 
	{
		Random rand = new Random();
		for(int i = 0; i <= 99; i++)
		{
			int x = rand.nextInt(99);
			int y = rand.nextInt(99);
			int product = x*y;
			if(product == rand.nextInt(1000))
			{
				SysLib.cout("amazing!!!\n");
			}
		}
	}
}
