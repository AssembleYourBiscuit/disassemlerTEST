import java.util.Random;

public class Test4 extends Thread
{
	boolean useCache;
	int testCase;
	Random rand;
	
	public Test4(String args[])
	{
		if(args.length != 2)
		{
			System.out.println("bad args");
			System.exit(1);
		}
		if(args[0].equalsIgnoreCase("enabled"))
		{
			useCache = true;
		}
		else if(args[0].equalsIgnoreCase("disabled"))
		{
			useCache = false;
		}
		else
		{
			System.out.println("bad args");
			System.exit(1);
		}
		if(Integer.parseInt(args[1]) < 1 || Integer.parseInt(args[1]) > 4)
		{
			System.out.println("bad args (1-4)");
			System.exit(1);
		}
		testCase = Integer.parseInt(args[1]);
		rand = new Random();
	}
	
	private void random()
	{
		System.out.println("Test: Random Access\nRunning...");
		//byte array to randomly write to disk
		byte[] writeBytes = new byte[512];
		//byte array to contain read bytes from disk
		byte[] readBytes = new byte[512];
		//generate random bytes to write
		rand.nextBytes(writeBytes);
		//write 100 randon byte writes of 512 bytes each
		long startWrite = System.currentTimeMillis();
		for(int i = 0; i < 100; i++)
		{
			int block = rand.nextInt(1000);
			write(block, writeBytes);
		}
		long endWrite = System.currentTimeMillis();
		//read from 100 random locations from disk into byte array
		long startRead = System.currentTimeMillis();
		for(int i = 0; i < 100; i++)
		{
			int block = rand.nextInt(1000);
			read(block, readBytes);
		}
		long endRead = System.currentTimeMillis();
		System.out.println("Average write time: " + (endWrite - startWrite) + " ms");
		System.out.println("Average read time: " + (endRead - startRead) + " ms");
	}
	
	private void localized()
	{
		System.out.println("Test: Localized Access\nRunning...");
		//byte array to randomly write to disk
		byte[] writeBytes = new byte[512];
		//byte array to contain read bytes from disk
		byte[] readBytes = new byte[512];
		//generate random bytes to write
		rand.nextBytes(writeBytes);
		//write to only first few blocks 100 times to maximize cache
		long startWrite = System.currentTimeMillis();
		for(int i = 0; i < 1000; i++)
		{
			int block = rand.nextInt(4);
			write(block, writeBytes);
		}
		long endWrite = System.currentTimeMillis();
		//read from 100 random locations from disk into byte array
		long startRead = System.currentTimeMillis();
		for(int i = 0; i < 1000; i++)
		{
			int block = rand.nextInt(4);
			read(block, readBytes);
		}
		long endRead = System.currentTimeMillis();
		System.out.println("Average write time: " + (endWrite - startWrite) + " ms");
		System.out.println("Average read time: " + (endRead - startRead) + " ms");
	}
	
	private void mixed()
	{
		System.out.println("Test: Mixed Access\nRunning...");
		//byte array to randomly write to disk
		byte[] writeBytes = new byte[512];
		//byte array to contain read bytes from disk
		byte[] readBytes = new byte[512];
		//generate random bytes to write
		rand.nextBytes(writeBytes);
		//90 percent local, 10 percent random
		long startWrite = System.currentTimeMillis();
		for(int i = 0; i < 100; i++)
		{
			//if mod == 9, this is the ten percent case for random access
			int mod = i % 10;
			if(mod == 9)
			{
				int block = rand.nextInt(1000);
				write(block, writeBytes);
			}
			else
			{
				int block = rand.nextInt(4);
				write(block, writeBytes);
			}
		}
		long endWrite = System.currentTimeMillis();
		//read from 100 random locations from disk into byte array
		long startRead = System.currentTimeMillis();
		for(int i = 0; i < 100; i++)
		{
			//if mod == 9, this is the ten percent case for random access
			int mod = i % 10;
			if(mod == 9)
			{
				int block = rand.nextInt(1000);
				read(block, readBytes);
			}
			else
			{
				int block = rand.nextInt(4);
				read(block, readBytes);
			}
		}
		long endRead = System.currentTimeMillis();
		System.out.println("Average write time: " + (endWrite - startWrite) + " ms");
		System.out.println("Average read time: " + (endRead - startRead) + " ms");
	}
	
	private void adversary()
	{
		System.out.println("Test: Adversary Access\nRunning...");
		//byte array to randomly write to disk
		byte[] writeBytes = new byte[512];
		//byte array to contain read bytes from disk
		byte[] readBytes = new byte[512];
		//generate random bytes to write
		rand.nextBytes(writeBytes);
		//writes to 100 blocks, never the same one twice
		long startWrite = System.currentTimeMillis();
		for(int i = 0; i < 100; i++)
		{
			write(i * 10 + 1, writeBytes);
		}
		long endWrite = System.currentTimeMillis();
		//rads from 100 blocks, never the same one twice
		long startRead = System.currentTimeMillis();
		for(int i = 0; i < 100; i++)
		{
			read(i * 10 + 1, readBytes);
		}
		long endRead = System.currentTimeMillis();
		System.out.println("Average write time: " + (endWrite - startWrite) + " ms");
		System.out.println("Average read time: " + (endRead - startRead) + " ms");
	}
	
	private void read(int blockID, byte[] buffer) 
	{
        if (useCache) 
        {
            SysLib.cread(blockID, buffer);
        } 
        else 
        {
            SysLib.rawread(blockID, buffer);
        }
    }

    private void write(int blockID, byte[] buffer) 
    {
        if (useCache) 
        {
            SysLib.cwrite(blockID, buffer);
        } 
        else 
        {
            SysLib.rawwrite(blockID, buffer);
        }
    }
    
    public void run()
    {
    	SysLib.flush();
    	switch(testCase)
    	{
    	case 1:
    		random();
    		break;
    	case 2:
    		localized();
    		break;
    	case 3:
    		mixed();
    		break;
    	case 4:
    		adversary();
    		break;
    	default:
    		System.out.println("Something has gone terribly wrong");
    	}
    	SysLib.exit();
    }
}