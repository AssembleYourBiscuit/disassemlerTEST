/**
 * File:	 TestThread3b.java
 * Author:   Nicolas Michael
 * Date:	 May 13, 2015
 * 
 * This class is called by Test3.java to perform random
 * computations to test run time and waiting capabilities
 * of newly added monitors to threados
 */ 
 
import java.util.Random;
 
class TestThread3b extends Thread 
{ 
	public void run() 
	{
		SysLib.cout("IO thread started\n");
		IO();
		SysLib.exit();
	}
  
	/**
	 * performs random IO
	 */ 
	private void IO() 
	{
		Random rand = new Random();
		byte[] data = new byte[512];
		for(int i = 0; i <= 99; i++)
		{
			SysLib.rawread(rand.nextInt(100), data);
			rand.nextBytes(data);
			SysLib.rawwrite(rand.nextInt(100), data);
		}
	}
}
