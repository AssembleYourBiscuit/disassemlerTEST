import java.util.ArrayList;

/**
 * Class: 		Cache.java
 * Author:		Nicolas Michael
 * Date: 		May 27, 2015
 * 
 * Description: The Cache class provides the interfaces; read, write, sync, and flush
 * 				to assist in reading and writing to a simulated cache system in ThreadOS.
 * 				This class has been tested with Test4.java and shows great improvement
 * 				from non-cached read and writes.
 */
public class Cache
{
	int numBlocks;
	int blockSize;
	int nodePtr;
	ArrayList<Node> circularQueue;
	
	/**
	 * Method:		Constructor
	 * 
	 * Description:	Instantiates the circular queue with default node instances
	 * 				representing an empty cache. 
	 * 
	 * @param blockSize The size of data each block can hold
	 * @param numBlocks The number of dick blocks, each of size blockSize
	 */
	public Cache(int blockSize, int numBlocks)
	{
		this.circularQueue = new ArrayList<Node>();
		this.numBlocks = numBlocks;
		this.blockSize = blockSize;
		iniQueue();
		this.nodePtr = 0;
	}
	
	/**
	 * Method		iniQueue
	 * 
	 * Description	Initializes the circular queue with default Node data. 
	 * 				Queue size will be equal to numBlocks
	 */
	private void iniQueue()
	{
		for(int i = 0; i < numBlocks; i++)
		{
			circularQueue.add(new Node());
		}
	}
	
	/**
	 * Method		read
	 * 
	 * Description	Reads data from disk block number blockID into buffer 
	 * 				byte array.
	 * 				
	 *@param blockID The block to be read from.
	 *@param buffer The byte array that read data will be copied into
	 *@return boolean Returns false if blockID < 0
	 */
	public synchronized boolean read(int blockID, byte[] buffer)
	{
		if(blockID < 0)
		{
			System.out.println("Something has gone terrible wrong");
			return false;
		}
		byte[] newBuff;
		for(Node node: circularQueue)
		{
			if(node.blockNum == blockID)
			{
				newBuff = node.buffer;
	            System.arraycopy(newBuff, 0, buffer, 0, blockSize);
				node.refBit = true;
				return true;
			}
		}
		int openIndex = findOpenSpace();
		if(openIndex < 0) return false;
		SysLib.rawread(blockID, buffer);
		newBuff = new byte[blockSize];
		System.arraycopy(buffer, 0, newBuff, 0, this.blockSize);
		Node newNode = circularQueue.get(openIndex);
		newNode.blockNum = blockID;
		newNode.buffer = newBuff;
		newNode.refBit = true;
		return true;
	}
	
	/**
	 * Method		write
	 * 
	 * Description	Writes data in byte array buffer to disk at block number 
	 * 				blockID.
	 * 
	 * @param blockID The block number to be written to.
	 * @param buffer The byte array that will be written to disk
	 * @return boolean Returns false if blockID < 0
	 */
	public synchronized boolean write(int blockID, byte[] buffer)
	{
		if(blockID < 0)
		{
			System.out.println("Something has gone terrible wrong");
			return false;
		}
		byte[] newBuff = new byte[blockSize];
		System.arraycopy(buffer, 0, newBuff, 0, this.blockSize);
		for(Node node: circularQueue)
		{
			if(node.blockNum == blockID)
			{
				node.buffer = newBuff;
				node.refBit = true;
				node.dirtyBit = true;
				return true;
			}
		}
		int openIndex = findOpenSpace();
		if(openIndex < 0) return false;
		Node thisNode = circularQueue.get(openIndex);
		thisNode.blockNum = blockID;
		thisNode.refBit = true;
		thisNode.dirtyBit = true;
		thisNode.buffer = newBuff;
		return true;
	}
	
	/**
	 * Method		sync
	 * 
	 * Description	Writes all data in cache to disk and syncs back with ThreadOS
	 */
	public synchronized void sync() 
	{
        for (int i = 0; i < circularQueue.size(); i++)
        {
            writeDirtyBlock(i);
        }
        SysLib.sync();
    }
	
	/**
	 * Method		flush
	 * 
	 * Description	Writes all data in cache to disk and syncs back with ThreadOS
	 * 				and resets all cache data to default values
	 */
	public synchronized void flush() 
	{
        for (int i = 0; i < circularQueue.size(); i++) 
        {
            writeDirtyBlock(i);
            circularQueue.get(i).blockNum = -1;
            circularQueue.get(i).refBit = false;
            circularQueue.get(i).dirtyBit = false;
            circularQueue.get(i).buffer = null;
        }
        SysLib.sync();
    }
	
	/**
	 * Method		findOpenSpace
	 * 
	 * Description	Searches the circular queue for an open space so that
	 * 				new data can be written to the cache. If none exists, 
	 * 				a search for data that is not being referenced will 
	 * 				be selected. Preference towards data that is not dirty.
	 * 
	 * @param int	The index of next available cache space that is safe
	 * 				to override.
	 */
	private int findOpenSpace()
	{
		for(Node node: circularQueue)
		{
			if(node.blockNum == -1)
			{
				return circularQueue.indexOf(node);
			}
		}
		int tempIndex = -1;
		for(int i = 0; i < circularQueue.size(); i++)
		{
            if (!circularQueue.get(nodePtr).refBit) 
            {
                if(!circularQueue.get(nodePtr).dirtyBit)
                {
                	return nodePtr;
                }
            }
            tempIndex = nodePtr;
            circularQueue.get(nodePtr).refBit = false;
            incrementPtr();
		}
		writeDirtyBlock(tempIndex);
		return tempIndex;
	}
	
	/**
	 * Method		writeDirtyBlock
	 * 
	 * Description	Writes cached data to disk if it has been changed in cache
	 * 				but not in memory.
	 * 
	 * @param index	The index of the cached data in the queue to be written to disk
	 */
	private void writeDirtyBlock(int index) 
	{
        if (circularQueue.get(index).blockNum != -1 && 
        		circularQueue.get(index).dirtyBit) 
        {
            byte[] arrby = circularQueue.get(index).buffer;
            SysLib.rawwrite(circularQueue.get(index).blockNum, arrby);
            circularQueue.get(index).dirtyBit = false;
        }
    }
	
	/**
	 * Method		incrementPtr
	 * 
	 * Description	Turns the ArrayList into a circular queue by returning
	 * 				current index to index 0 when the end of the list has
	 * 				been reached
	 */
	private void incrementPtr()
	{
		nodePtr++;
		if(nodePtr == circularQueue.size())
		{
			nodePtr = 0;
		}
	}
	
	/**
	 * Class		Node
	 * Description	Encaspulates individual cache data, including, reference bit,
	 * 				dirty bit byte array buffer and correspoding block id
	 */
	class Node
	{
		boolean refBit;
		boolean dirtyBit;
		int blockNum;
		byte[] buffer;
		
		void Node()
		{
			blockNum = -1;
			buffer = new byte[blockSize];
		}
	}
}
