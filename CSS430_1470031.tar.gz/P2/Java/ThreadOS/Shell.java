import java.util.*;
/**
 * Shell.java
 * Author : Nicolas Michael
 * Date : 4/15/15
 * 
 * Description:
 * This is a shell implementation for the ThreadOS Package.
 * This shell will display a prompt for program execution.
 * Concurrent and sequential execution is supported with & and ;
 * delimeters respectively in between arguments.
 * Enter Q to quit the shell.
 * 
 * */
class Shell extends Thread
{	
	//implemented run method from parent Thread
	public void run()
	{	
		int id = 1;
		
		while (true)
		{
			//display prompt and get user input
			SysLib.cout("shell[" + id + "]% ");
			StringBuffer buffer = new StringBuffer();
			SysLib.cin(buffer);
			
			//check if user wants to quit
			if(buffer.toString().equalsIgnoreCase("q"))
			{
				//this does not seem to quit fast enough
				//allows more loops to execute before quitting
				SysLib.exit();
			}
			
			//array for all args (multiple programs)
			String[] parsedArgs = SysLib.stringToArgs(buffer.toString());
			//array for one set of args
			ArrayList<String> thisCmd = new ArrayList<String>();

			//loop length of all args and grab subset to put in arrayList
			//for execution. If delimerter, handle!
			for(int i = 0; i < parsedArgs.length; i++)
			{
				//if concurrent
				if(parsedArgs[i].equals("&"))
				{
					//execute
					SysLib.exec(thisCmd.toArray(new String[thisCmd.size()]));
					thisCmd.clear();
				}
				//if sequential
				else if(parsedArgs[i].equals(";"))
				{
					//execute and wait for child thread to finish
					int tid = SysLib.exec(thisCmd.toArray(new String[thisCmd.size()]));
					thisCmd.clear();
					//join while not child id. final join will be correct child
					while(SysLib.join() != tid);
				}
				else
				{
					//add token to args subset
					thisCmd.add(parsedArgs[i]);
				}
			}
			id++;
		}
	}
}
