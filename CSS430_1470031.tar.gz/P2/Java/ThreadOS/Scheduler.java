import java.util.*;

public class Scheduler extends Thread
{
    private Vector[] queueList;
    private int timeSlice;
    private static final int DEFAULT_TIME_SLICE = 1000;
    private int currentQueueLevel;
    private TCB currentTCB;
    private boolean DEBUG = false;

    // New data added to p161 
    private boolean[] tids; // Indicate which ids have been used
    private static final int DEFAULT_MAX_THREADS = 10000;

    // A new feature added to p161 
    // Allocate an ID array, each element indicating if that id has been used
    private int nextId = 0;
    private void initTid( int maxThreads ) {
	tids = new boolean[maxThreads];
	for ( int i = 0; i < maxThreads; i++ )
	    tids[i] = false;
    }

    // A new feature added to p161 
    // Search an available thread ID and provide a new thread with this ID
    private int getNewTid( ) {
	for ( int i = 0; i < tids.length; i++ ) {
	    int tentative = ( nextId + i ) % tids.length;
	    if ( tids[tentative] == false ) {
		tids[tentative] = true;
		nextId = ( tentative + 1 ) % tids.length;
		return tentative;
	    }
	}
	return -1;
    }

    // A new feature added to p161 
    // Return the thread ID and set the corresponding tids element to be unused
    private boolean returnTid( int tid ) {
	if ( tid >= 0 && tid < tids.length && tids[tid] == true ) {
	    tids[tid] = false;
	    return true;
	}
	return false;
    }

    // A new feature added to p161 
    // Retrieve the current thread's TCB from the queue
    public TCB getMyTcb( ) {
	Thread myThread = Thread.currentThread( ); // Get my thread object
	synchronized( queueList ) {
	    for ( int i = 0; i < queueList.length; i++ ) {
			for(int j = 0; j < queueList[i].size(); j++){
				TCB tcb = ( TCB )queueList[i].elementAt( j );
				Thread thread = tcb.getThread( );
				if ( thread == myThread ) // if this is my TCB, return it
					return tcb;
				}
		}
	}
	return null;
    }

    // A new feature added to p161 
    // Return the maximal number of threads to be spawned in the system
    public int getMaxThreads( ) {
		return tids.length;
    }

    public Scheduler( ) {
		timeSlice = DEFAULT_TIME_SLICE;
		queueList = new Vector[3];
		queueList[0] = new Vector();
		queueList[1] = new Vector();
		queueList[2] = new Vector();
		initTid( DEFAULT_MAX_THREADS );
    }

    public Scheduler( int quantum ) {
		timeSlice = quantum;
		queueList = new Vector[3];
		queueList[0] = new Vector();
		queueList[1] = new Vector();
		queueList[2] = new Vector();
		initTid( DEFAULT_MAX_THREADS );
    }

    // A new feature added to p161 
    // A constructor to receive the max number of threads to be spawned
    public Scheduler( int quantum, int maxThreads ) {
		timeSlice = quantum;
		queueList = new Vector[3];
		queueList[0] = new Vector();
		queueList[1] = new Vector();
		queueList[2] = new Vector();
		initTid( maxThreads );
    }
    
	//Changed to timeslice / 2
    private void schedulerSleep( ) {
	try {
	    Thread.sleep( timeSlice / 2  );
	} catch ( InterruptedException e ) {
	}
    }

    // modified for adding to array of queues
    public TCB addThread( Thread t ) {
	//t.setPriority( 2 );
	TCB parentTcb = getMyTcb( ); // get my TCB and find my TID
	int pid = ( parentTcb != null ) ? parentTcb.getTid( ) : -1;
	int tid = getNewTid( ); // get a new TID
	if ( tid == -1)
	    return null;
	TCB tcb = new TCB( t, tid, pid ); // create a new TCB
	queueList[0].add( tcb );
	return tcb;
    }

    // A new feature added to p161
    // Removing the TCB of a terminating thread
    public boolean deleteThread( ) {
	TCB tcb = getMyTcb( ); 
	if ( tcb!= null )
	    return tcb.setTerminated( );
	else
	    return false;
    }
    
	//dont use!
    public void sleepThread( int milliseconds ) {
	try {
	    sleep( milliseconds );
	} catch ( InterruptedException e ) { }
    }
    
    /**
     * Prints contents of all three queues to the console
     * if DEBUG is set to true, for debugging purposes.
     * 
     * @param time the time stamp for each call
     * 
     */
    private void dumpQueue(int time)
    {
		if(DEBUG){
			System.out.println("Time: " + time);
			for(int i = 0 ; i < 3; i++)
			{
				System.out.print("Queue level " + i + " --> ");
				for(int j = 0; j < queueList[i].size(); j++)
				{
					TCB tcb = (TCB) queueList[i].get(j);
					System.out.print("[PID: " + tcb.getPid() + " TID: " 
					+ tcb.getTid() + "] --> ");
				}
				System.out.println();
			}
		}
	}
    
    /**
     * Checks if there are new threads in a higher priority
     * queue relative to currentQueueLevel
     * 
     * @return boolean true if new threads have been added, false
     * otherwise. If currentQueueLevel is 0, always return false
     */
    private boolean newThreads()
    {
		if(currentQueueLevel == 1) 
		{
			return queueList[0].size() != 0;
		}
		if(currentQueueLevel == 2)
		{
			return (queueList[0].size() != 0 ||
					queueList[1].size() != 0);
		}
		return false;
	}	
	
	/**
	 * Removes thread from current queue and places it in either
	 * a lower priority queue (currentQueueLevel + 1), or the end 
	 * of its current queue if currentQueuelevel is 2
	 */
	private void demoteThread()
	{
		if(currentQueueLevel == 2)
		{
			//send to the back
			queueList[2].remove( currentTCB ); 
			queueList[2].add( currentTCB );
		}
		//send to next queue
		else if(currentQueueLevel == 0 || 
				currentQueueLevel == 1)
		{
			queueList[currentQueueLevel].remove( currentTCB ); 
			queueList[currentQueueLevel + 1].add( currentTCB );
		}
		//"should" not happen but just in case
		else
		{
			System.out.println("Something has gone horribly wrong");
		}
	}
    
    /**
     * Gets the current TCB from the queueList. Highest priority
     * TCB is returned
     * 
     * @return TCB The highest priority TCB or null if none exist
     */
    private TCB getCurrentTCB()
    {
		currentQueueLevel = 0;
		for(int i = 0; i < queueList.length; i++)
		{
			if(queueList[i].size() != 0)
			{
				currentQueueLevel = i;
				currentTCB = (TCB)queueList[i].firstElement();
				return currentTCB;
			}
		}
		return null;
    }
    
    // A modified run of p161
    public void run( ) {
	Thread current = null;
	int count = 0;

	//this.setPriority( 6 );
	while ( true ) {
	    try {
		// get the next TCB and its thrad
		currentTCB = getCurrentTCB();
		if (currentTCB == null)
		    continue;
		
		if ( currentTCB.getTerminated( ) == true ) {
		    queueList[currentQueueLevel].remove( currentTCB );
		    returnTid( currentTCB.getTid( ) );
		    continue;
		}
		count++;
		dumpQueue(count);
		current = currentTCB.getThread( );
		if ( current != null ) {
		    if ( current.isAlive( ) )
				current.resume();
			//current.setPriority( 4 );
		    else {
			// Spawn must be controlled by Scheduler
			// Scheduler must start a new thread
			current.start( ); 
		    }
		}
		//execute thread for its corresponding timeslice and 
		//check for higher priority threads
		for(int i = 0; i <= currentQueueLevel; i++)
		{
			schedulerSleep();
			if(newThreads()) break;
			if(currentQueueLevel == 2 && i == 2)
			{
				schedulerSleep();
			}
		}

		synchronized ( queueList ) {
		    if ( current != null && current.isAlive( ) )
				current.suspend();
			//did not finish in time, lower priority
		    demoteThread();
		}
	    } catch ( NullPointerException e3 ) { };
	}
    }

}
