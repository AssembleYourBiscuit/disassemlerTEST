import java.util.ArrayList;

public class SyncQueue
{
	private ArrayList<QueueNode> queue;
	int size;
	
	/**
	 * Constructor - sets queue size to 10 by default
	 */
	public SyncQueue()
	{
		this(10);
	}
	
	/**
	 *Constructor - sets queue size to condMax 
	 * 
	 * @param condMax size fo the queue
	 */
	public SyncQueue(int condMax)
	{
		size = condMax;
		queue = new ArrayList();
		initializeQueue();
	}
	
	/**
	 * enqueue and sleep - put to sleep
	 * 
	 * @param condition condition code
	 */ 
	public int enqueueAndSleep(int condition)
	{
		if(condition >= 0 && condition < size)
		{
			return queue.get(condition).sleep();
		}
		return -1;
	}
	
	/**
	 * dequeue and wake up - wakes up
	 * 
	 * @param condition condition code
	 */ 
	public void dequeueAndWakeup(int condition)
	{
		if (condition >= 0 && condition < size) 
		{
			queue.get(condition).wakeup(queue.size() -1);
		}
	}
	
	/**
	 * dequeue and wake up - wakes up
	 * 
	 * @param condition condition code
	 * @param tid the thread id
	 */ 
	public void dequeueAndWakeup(int condition, int tid) 
	{
		if (condition >= 0 && condition < queue.size())
		{
			queue.get(condition).wakeup(tid);
		}
	}
	
	/**
	 * initialize queue - instantiates all nodes
	 */ 
	private void initializeQueue()
	{
		for(int i = 0; i < size; i++)
		{
			QueueNode node = new QueueNode();
			queue.add(node);
		}
	}
}

