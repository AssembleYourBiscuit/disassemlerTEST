import java.util.ArrayList;

public class QueueNode 
{
	private ArrayList<Integer> queue;
  
	public QueueNode() 
	{
		queue = new ArrayList();
	}
  
	/**
	 * sleep - sleeps and returns waiting thread
	 */ 
	public synchronized int sleep() 
	{
		if (queue.size() == 0)
		{
		    try 
		    {
		        wait();
		    } catch (InterruptedException iex) {}
		}
		return queue.remove(queue.size() - 1);
	}
  
	/**
	 * wakeup - wakes and notifies
	 */ 
	public synchronized void wakeup(int tid) 
	{
		queue.add(tid);
		notify();
	}
}
